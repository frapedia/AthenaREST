<?php return array('dependencies' => array(), 'version' => '0ec2eaf39c31095cdc0d');
