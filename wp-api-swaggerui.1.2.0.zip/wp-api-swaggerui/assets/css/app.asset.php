<?php return array('dependencies' => array(), 'version' => '789d1305ed98892b948d');
