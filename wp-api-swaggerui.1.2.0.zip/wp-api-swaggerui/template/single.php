<!DOCTYPE html>
<html lang="<?php language_attributes(); ?>">
<head>
    <?php wp_head(); ?>
</head>
<body>
<div id="swagger-ui"></div>
<?php wp_footer(); ?>
</body>
</html>