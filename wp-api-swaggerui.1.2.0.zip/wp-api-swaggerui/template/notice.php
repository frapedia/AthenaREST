<div class="notice notice-success is-dismissible">
	<p><?php echo esc_attr( 'Settings saved.' ); ?></p>
</div>